import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
void main(){
  runApp(Project1());
}
class Project1 extends StatelessWidget {
  const Project1({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: firstpage(),
      // secondpage(),
      // thirdpage(),
      //fourthpage(),
    );
  }
}

class firstpage extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(child: Text("Primary page")),
        actions: [
          Icon(Icons.accessibility_new_rounded)
        ],
        leading: Icon(Icons.ac_unit),

      ),
      body: SafeArea(
        child: ListView(
          children: [

            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                  height: 100,
                  width: 10,
                  child: Text("Bangladesh",textAlign: TextAlign.center,style: TextStyle(fontSize: 50),)
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(20.0),

              child: Container(
                height: 200,
                width: 0,
                child: TextButton(
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all<Color>(Colors.green),
                    ),



                    onPressed: (){

                      Navigator.push(context, MaterialPageRoute(builder: (context)=> secondpage()));

                    }, child: Text("Dhaka Capital",style: TextStyle(fontSize: 30,color: Colors.black),)
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Container(
                height: 200,
                width: 0,
                child: OutlinedButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(Colors.amber),
                  ),



                    onPressed: (){

                      Navigator.push(context, MaterialPageRoute(builder: (context)=> thirdpage()));

                    }, child: Text("Mymensingh Division",style: TextStyle(fontSize: 30,color: Colors.black),),


                )
              )
            ),
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Container(
                height: 200,
                width: 0,
                child: ElevatedButton(
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all<Color>(Colors.purple),
                    ),

                    onPressed: (){

                      Navigator.push(context, MaterialPageRoute(builder: (context)=> fourthpage()));

                    }, child: Text("Sherpur Town",style: TextStyle(fontSize: 30,color: Colors.black), ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
class secondpage extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:  ListView(
        children: [
          Center(child: Text("Capital City",style:TextStyle(fontWeight: FontWeight.bold, fontSize: 100) ,)),
          Text("After decades cleaning the sewers of Dhaka, Bangladesh’s crowded capital, Sujon Lal Routh has seen plenty of misery. But the tragedy of 2008 was the worst. After a day of heavy rainfall left the streets flooded – as usual – seven workers were assigned to clear a blocked manhole in Rampura, in the centre of the city. Normally, cleaners cling to ropes to stop them getting sucked in by surging water when they clear blockages. But this group were new to the job. “They didn’t know about the impending danger or how to work in that situation,” says Sujon. “So, sewer water swallowed them.”"),

          Align(
            alignment: Alignment.bottomCenter,

            child: ElevatedButton(
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(Colors.red),
                ),

                onPressed: (){

                  Navigator.push(context, MaterialPageRoute(builder: (context)=> firstpage()));

                }, child: Text("Back to Previous",
            )),
          ),
        ],
      ),
    );
  }
}
class thirdpage extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:  ListView(
        children: [

          Center(child: Text("Educational City",style:TextStyle(fontWeight: FontWeight.bold, fontSize: 100) ,)),
          Text("Once known for its glass-bangle manufacture, it now has textile and steel mills. It was incorporated as a municipality in 1869. Mymensingh is noted for its many educational institutions, including Bangladesh Agricultural University (1961), Jatiya Kabi Kazi Nazrul Islam University (2005) to the south of the city in Trishal, medical and engineering colleges, and a cadet college "),
          Container( height: 100,
            child: ElevatedButton(
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(Colors.red),
                ),

                onPressed: (){

                  Navigator.push(context, MaterialPageRoute(builder: (context)=> firstpage()));

                }, child: Text("Back to Previous 2",
            )),
          ),
        ],
      ),
    );
  }
}
class fourthpage extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:
      ListView(
        children: [
          Image.asset('assets/images/'),
          Center(child: Text("Sherpur Shahid Daroga Ali Powro Park",style:TextStyle(fontWeight: FontWeight.bold, fontSize: 100) ,)),
          Text("Sherpur Shahid Daroga Ali Powro Park is popular park in Sherpur Sadar.It is situated in chokpathok,Sherpur Sadar"),
          Container(
            height: 100,
            width: 0,
            child: ElevatedButton(
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
                ),

                onPressed: (){

                  Navigator.push(context, MaterialPageRoute(builder: (context)=> firstpage()));

                }, child:Text("Back to previous 3")
            ),
          ),
        ],
      ),
    );
  }
}


